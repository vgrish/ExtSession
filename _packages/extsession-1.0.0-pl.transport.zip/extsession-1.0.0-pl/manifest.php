<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for ExtSession.

```
1.0.0-pl (12.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# ExtSession

### Extending standard sessions for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>

#### Manual

After installation, set the setting
**session_handler_class** = **ExtSession\\ExtSessionHandler**.
The default value **MODX\\Revolution\\modSessionHandler**

#### Licence

```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '3bbf66d7b625702ab236bfba331f4245',
      'native_key' => '3bbf66d7b625702ab236bfba331f4245',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/d85d082c1b05f26d60f8f81dc3b118d3.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '5e5b61f604fdb0e27b4ea0ade2181ff5',
      'native_key' => '5e5b61f604fdb0e27b4ea0ade2181ff5',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/322597a33f8271158f1d53b31d103331.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '6d284b6ebd33a42d39929df7e059ccac',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modNamespace/276399c29d841b8f2376fa9404e3c879.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92eda4f50f12a799ffe3c7f46b49eb6d',
      'native_key' => 'extsession_bot_patterns',
      'filename' => 'MODX/Revolution/modSystemSetting/a54cc1c1349f47cfb8bc8b7d1a0dba19.vehicle',
      'namespace' => 'extsession',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '056c962950fd137c412d9830a460d4e5',
      'native_key' => 'extsession_bot_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/ff2e1f78d056319d2e219587d2aabdf3.vehicle',
      'namespace' => 'extsession',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bba3d505111d0ad697953493be0a5049',
      'native_key' => 'extsession_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/9029d0b263633c35ab146007c2efb8ba.vehicle',
      'namespace' => 'extsession',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8fd0dd1a2d9d35b467cd65be33024d14',
      'native_key' => 'extsession_not_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/000ca39115426f76bdd9af71839476bb.vehicle',
      'namespace' => 'extsession',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '384e63b4879c3e3cb811cd6f1cbd4b8d',
      'native_key' => 'extsession_limit_clearing',
      'filename' => 'MODX/Revolution/modSystemSetting/a07cb0e893f48e1caf9cddeabcec268f.vehicle',
      'namespace' => 'extsession',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c3b22ae6ed78cd7686febd2757561b3e',
      'native_key' => 'extsession_standart_clearing',
      'filename' => 'MODX/Revolution/modSystemSetting/72b7285ddde3a77e080eb9588f23b405.vehicle',
      'namespace' => 'extsession',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '46ea2277b777860fff59cfd9ff128195',
      'native_key' => 'extsession_show_log',
      'filename' => 'MODX/Revolution/modSystemSetting/8ab228ee5ef5f75fc2eb5f470b678b7f.vehicle',
      'namespace' => 'extsession',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '4c107cf5920494ddc4faf49564dae804',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modMenu/19cf72be1ae5829760051cd65a151451.vehicle',
      'namespace' => 'extsession',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'cec3252a3bb4b4861c5080b3386aa821',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/942af48fc4ac91e6da56e326911b4e89.vehicle',
    ),
  ),
);