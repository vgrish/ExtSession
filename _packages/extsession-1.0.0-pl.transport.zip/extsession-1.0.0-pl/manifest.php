<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for ExtSession.

```
1.0.0-pl (12.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# ExtSession

### Extending standard sessions for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>

#### Manual

After installation, set the setting
**session_handler_class** = **ExtSession\\ExtSessionHandler**.
The default value **MODX\\Revolution\\modSessionHandler**

#### Licence

```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c2c9a272a09f3f864c4ab8d9887816c4',
      'native_key' => 'c2c9a272a09f3f864c4ab8d9887816c4',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/3c610b568d78bd29289b872cd2330475.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '9624054ed146b87602ab8c118db56d82',
      'native_key' => '9624054ed146b87602ab8c118db56d82',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/9dc444383e9847d1d18aa3cb63f005b4.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'bfaf600d8d0448d2559b27dd1db9f80d',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modNamespace/e43b7cf2130b8d730efa63a42ed341a0.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0a385f3bd27ad653f2ed51797987a3d5',
      'native_key' => 'extsession_bot_patterns',
      'filename' => 'MODX/Revolution/modSystemSetting/815c0c4fa35cb1c05482a298864789d4.vehicle',
      'namespace' => 'extsession',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd5f4e55c4074fb188e832e898ee49644',
      'native_key' => 'extsession_bot_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/a53a6a1e33e57c69fae3a410db2c8928.vehicle',
      'namespace' => 'extsession',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '58661f42b548085ffd216f29fed9c60f',
      'native_key' => 'extsession_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/24156460c6844002050b9376bdac62f8.vehicle',
      'namespace' => 'extsession',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6daaf610e04b294c64509e5d2a99063b',
      'native_key' => 'extsession_not_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/3f651ab95a4f6537f370b0d4d3b1a725.vehicle',
      'namespace' => 'extsession',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5de3aadcad63d5451bfb59cff17e9ea2',
      'native_key' => 'extsession_standart_clearing',
      'filename' => 'MODX/Revolution/modSystemSetting/84d8642edb27facadb0ed876e60544c3.vehicle',
      'namespace' => 'extsession',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7fbea47e0f30cc51ec012dfd3c87e9a6',
      'native_key' => 'extsession_show_log',
      'filename' => 'MODX/Revolution/modSystemSetting/921e8bd7f49e399f730987688fe29ed9.vehicle',
      'namespace' => 'extsession',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '7d8be906cd2a3fc1064a11aab46981d6',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modMenu/cc701046d8a80678a0bb8771818759e3.vehicle',
      'namespace' => 'extsession',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '91b92052e04df5ede0553b5699a08a34',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/87d27812ef1052f2beb75df748d67f0d.vehicle',
    ),
  ),
);