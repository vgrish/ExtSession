<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for ExtSession.

```
1.0.0-pl (12.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# ExtSession

### Extending standard sessions for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>

#### Manual

After installation, set the setting
**session_handler_class** = **ExtSession\\ExtSessionHandler**.
The default value **MODX\\Revolution\\modSessionHandler**

#### Licence

```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '33080be81b0a40dc902aa9c6074b8dbf',
      'native_key' => '33080be81b0a40dc902aa9c6074b8dbf',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/29fdf05a79011a845566a165979e6902.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '307966e8a792671e5b0a2f854f869e9a',
      'native_key' => '307966e8a792671e5b0a2f854f869e9a',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/2758c54466d4b3fc10e1b1f6b8948ea9.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '909b3d46f6c4328920663e169135e00b',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modNamespace/a6b727e4fe4dc3179648c74792a44033.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '263006bcb2ff72ece2bbea9e63b522d7',
      'native_key' => 'extsession_bot_patterns',
      'filename' => 'MODX/Revolution/modSystemSetting/963973f436267d665c1fb7e75d72b6a7.vehicle',
      'namespace' => 'extsession',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '54d20455f57ac388f453cb43a0843ba9',
      'native_key' => 'extsession_bot_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/1efea8b125e56386463c62b268d82de8.vehicle',
      'namespace' => 'extsession',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0eebbe31e212c3b978bfd0f723ab1682',
      'native_key' => 'extsession_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/2ed170873e2a19e79dbd4e63dcb8560c.vehicle',
      'namespace' => 'extsession',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20f3c35d0153fe73a57c801bda9fa215',
      'native_key' => 'extsession_not_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/ab4676fdb55130f28bcc8da5d6d16ef3.vehicle',
      'namespace' => 'extsession',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2750a390ec75df531e7e3cbe8ed4e488',
      'native_key' => 'extsession_empty_user_agent_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/b79f0976634dcdcd274083f137e968fa.vehicle',
      'namespace' => 'extsession',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4198adf37d98269059c7b5972b838ff0',
      'native_key' => 'extsession_show_log',
      'filename' => 'MODX/Revolution/modSystemSetting/2212e26766a183d9c5e26ec6226325d8.vehicle',
      'namespace' => 'extsession',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '334e5a9b192422bcc1c47136d3ee3a0c',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modMenu/18eee41ac47c35a214e7910c1f7240cd.vehicle',
      'namespace' => 'extsession',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '99156d7b454091603a5f142bce8a329c',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/52938eb22c0d957f1d1c6b58c50fe1f7.vehicle',
    ),
  ),
);