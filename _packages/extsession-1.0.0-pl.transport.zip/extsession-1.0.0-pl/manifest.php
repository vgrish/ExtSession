<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog for ExtSession.

```
1.0.0-pl (12.02.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# ExtSession

### Extending standard sessions for MODx Revolution 3. 
### Author: Vgrish <vgrish@gmail.com>

#### Manual

After installation, set the setting
**session_handler_class** = **ExtSession\\ExtSessionHandler**.
The default value **MODX\\Revolution\\modSessionHandler**

#### Licence

```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.
Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=3.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'c83958e7dd4f56252b84e0db1a3c5fee',
      'native_key' => 'c83958e7dd4f56252b84e0db1a3c5fee',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/a1e3ad7b04f49a4713ce8841fc76f664.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '36d5c19119394ef151af6f463b4e49c9',
      'native_key' => '36d5c19119394ef151af6f463b4e49c9',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/252997afb68aeb0e64b4fbe1ec3de9df.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '9b53429e3c29f880809f2dc1dcb5cbc9',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modNamespace/693be2159584fe754a8677d24a847999.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '417946eb720009514152d5291374b27a',
      'native_key' => 'extsession_bot_patterns',
      'filename' => 'MODX/Revolution/modSystemSetting/0c23a832b19868137337f342f8b4b484.vehicle',
      'namespace' => 'extsession',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '22af8097fbef409e23a3cc75d8d406f8',
      'native_key' => 'extsession_bot_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/78dd752b04770319ed10825dbf051b5b.vehicle',
      'namespace' => 'extsession',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f3ab1c01189a8a2a8c7cd5d6e367a75',
      'native_key' => 'extsession_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/83822d19b9ce5a853c73f73fe5bb651a.vehicle',
      'namespace' => 'extsession',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '37b3dd1386fa738c62236b5e3dd7a0f6',
      'native_key' => 'extsession_not_empty_user_id_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/c6309aa611606980e98d1ff6bb91edc3.vehicle',
      'namespace' => 'extsession',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e0f3c2efdb29c0b3cfbcf964733e5e74',
      'native_key' => 'extsession_limit_clearing',
      'filename' => 'MODX/Revolution/modSystemSetting/67b0a7fe93aec8cb3a8eb3ca348a132e.vehicle',
      'namespace' => 'extsession',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0349184b4a485c59ef42158d08253561',
      'native_key' => 'extsession_standart_clearing',
      'filename' => 'MODX/Revolution/modSystemSetting/a2523e8bfb2ae27ec7461264bae8b646.vehicle',
      'namespace' => 'extsession',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c73643e9de2a132cda20b429600504c4',
      'native_key' => 'extsession_show_log',
      'filename' => 'MODX/Revolution/modSystemSetting/cc90ffb20dde5126d4fca4fdfcdaae9d.vehicle',
      'namespace' => 'extsession',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '76337e939a0bc58266dbedc130af9066',
      'native_key' => 'extsession',
      'filename' => 'MODX/Revolution/modMenu/46ce93c72f2db8841222c5c24bdf177b.vehicle',
      'namespace' => 'extsession',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '43bc1ffd4d3dbd5a6e2b3d5bfb995b5a',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modCategory/8b31caed016b1de2dc2be02872f53a2d.vehicle',
    ),
  ),
);