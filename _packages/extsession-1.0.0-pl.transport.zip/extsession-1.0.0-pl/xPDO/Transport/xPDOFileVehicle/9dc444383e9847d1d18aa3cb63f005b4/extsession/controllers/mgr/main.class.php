<?php

require_once dirname(__DIR__,2) . '/src/Controllers/Mgr/Main.php';

class ExtsessionMgrMainManagerController extends ExtSession\Controllers\Mgr\Main {

}