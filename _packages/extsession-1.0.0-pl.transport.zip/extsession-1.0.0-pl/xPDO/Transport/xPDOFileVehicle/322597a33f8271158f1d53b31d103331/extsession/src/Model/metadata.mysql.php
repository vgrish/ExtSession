<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'ExtSession\\Model',
    'namespacePrefix' => 'ExtSession',
    'class_map' => 
    array (
        'MODX\\Revolution\\modSession' => 
        array (
            0 => 'ExtSession\\Model\\Session',
        ),
    ),
);